package javamysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.Scanner;

// Dylan Bearman
// SDH2 - A
// R00190268
public class RunDB {
    
    // Creates a new instance of RunDB 
    public RunDB() {
    }
    
    public static void main(String[] args) {
        try {
            // Here i connect to my database and print out when connected
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/Projectv7?user=root&password=Spring2020" );
            System.out.println ("Database connection established \n");

            //Here i set up a loop to go through the menu
            Scanner input = new Scanner(System.in);
            boolean mainLoop = true;
            int choice;

            while(true){
                System.out.println("");
                System.out.println("Flight Main Menu");
                System.out.println("1: Add Flights");
                System.out.println("2: Add Customer");
                System.out.println("3: Book Flight");
                System.out.println("4: List Airlines");
                System.out.println("5: Make Payment");
                System.out.println("6: Flight Info");
                System.out.println("7: Delete Airline");
                System.out.println("8: Exit");
                System.out.println("Enter Your Menu Choice:");
                choice = input.nextInt();

            switch(choice){
                
            case 1:
                //Optionm 1
                //Add Flights
                
                //We ask the neccesarry information that is needed to add a flight
                String  flightno, price, source, destination, eta, numpassanger;
                System.out.println("\nPlease Enter the flightno (123456): ");
                flightno = input.next();
                System.out.println("\nPlease Enter the price (123.45): ");
                price = input.next();
                System.out.println("\nPlease Enter the source: ");
                source = input.next();
                System.out.println("\nPlease Enter the destination: ");
                destination = input.next();
                System.out.println("\nPlease Enter the E.T.A.: ");
                eta = input.next();
                System.out.println("\nPlease Enter the number of passangers: ");
                numpassanger = input.next();
                
                //We insert the information from above into the flights table
                String insertSQL_AF = "Insert into flights values (?, ?, ?, ?, ?)";
                PreparedStatement insertStmt_AF = con.prepareStatement(insertSQL_AF);
                insertStmt_AF.setString(1, flightno);
                insertStmt_AF.setString(2, source);
                insertStmt_AF.setString(3, destination);
                insertStmt_AF.setString(4, eta);
                insertStmt_AF.setString(5, numpassanger);
                insertStmt_AF.executeUpdate();
                insertStmt_AF.close();
                
                //We also insert that information into the price table
                String insertSQL_AFV1 = "Insert into price values (?, ?)";
                PreparedStatement insertStmt_AFV1 = con.prepareStatement(insertSQL_AFV1);
                insertStmt_AFV1.setString(1, flightno);
                insertStmt_AFV1.setString(2, price);
                insertStmt_AFV1.executeUpdate();
                insertStmt_AFV1.close();
                System.out.println("Request Processing");
                System.out.println("Customer Added");
                
                //We send a message to the screen to say the values 
                //were added and they can view the information printed below
                System.out.println("Request Processing");
                System.out.println("Customer Added");
                System.out.println("Please see below");
                
                //We print out the results from the flights table
                Statement AF = con.createStatement ();
                ResultSet AFV1 = AF.executeQuery ("SELECT * FROM Flights");
                System.out.println("");
                System.out.format("%20s %20s %20s %20s %20s", "Flight Number", "Source","Destination","E.T.A.","Number of passangers \n");
                System.out.print("----------------------------------------------------------------------------------------------------------");
                while (AFV1.next ()) {
                    String col1 = AFV1.getString ("flightno");
                    String col2 = AFV1.getString ("source");
                    String col3 = AFV1.getString ("destination");
                    String col4 = AFV1.getString ("eta");
                    String col5 = AFV1.getString ("numberpassenger");
                    System.out.println("");
                    System.out.format("%20s %20s %20s %20s %20s ", col1, col2, col3, col4, col5);}
                
                //We print out the information from the price table
                Statement AF1 = con.createStatement ();
                ResultSet AF1V1 = AF1.executeQuery ("SELECT * FROM Price");
                System.out.println("\n");
                System.out.format("%20s %20s","Flight Number", "Price \n");
                System.out.print("-----------------------------------------");
                while (AF1V1.next ()){
                    String col1 = AF1V1.getString ("flightno");
                    String col2 = AF1V1.getString ("price");
                    System.out.println("");
                    System.out.format("%20s %20s", col1, col2);}
                    System.out.println("");
                    
                break;

            case 2: 
                //Optionm 2
                //Delete Add Customer
                
                //We ask the neccesarry information that is needed to add a customer
                String customerid, fname, lname, address, email, phone, passportno;
                System.out.println("\nPlease Enter your customer id: ");
                customerid = input.next();
                System.out.println("\nPlease Enter your firstname: ");
                fname = input.next();
                System.out.println("\nPlease Enter your last name: ");
                lname = input.next();
                System.out.println("\nPlease Enter your address (Line 1): ");
                address = input.next();
                System.out.println("\nPlease Enter your email: ");
                email = input.next();
                System.out.println("\nPlease Enter your phone (0871234567): ");
                phone = input.next();
                System.out.println("\nPlease Enter your passportno (yes/no): ");
                passportno = input.next();
                
                //We insert the information from above into the customer table
                String insertSQL = "Insert into customer values (?, ?, ?, ?, ?, ?)";
                PreparedStatement insertStmt = con.prepareStatement(insertSQL);
                insertStmt.setString(1, customerid);
                insertStmt.setString(2, fname);
                insertStmt.setString(3, lname);
                insertStmt.setString(4, address);
                insertStmt.setString(5, email);
                insertStmt.setString(6, phone);
                insertStmt.executeUpdate();
                insertStmt.close();
                
                //We also insert that information into the passport table
                String insertSQLv2 = "Insert into passport values (?, ?)";
                PreparedStatement insertStmte = con.prepareStatement(insertSQLv2);
                insertStmte.setString(1, customerid);
                insertStmte.setString(2, passportno);
                insertStmte.executeUpdate();
                insertStmte.close();
                
                //We send a message to the screen to say the values 
                //were added and they can view the information printed below
                System.out.println("Request Processing");
                System.out.println("Customer Added");
                
                //We print out the results from the customer table
                Statement AC = con.createStatement ();
                ResultSet ACV1 = AC.executeQuery ("SELECT * FROM customer");
                System.out.println("");
                System.out.format("%20s %20s %20s %20s %20s %20s", "Customer ID", "First Name","Last Name","Address","Email","Mobile Number");
                System.out.print("----------------------------------------------------------------------------------------------------------");
                while (ACV1.next ()) {
                    String col1 = ACV1.getString ("customerid");
                    String col2 = ACV1.getString ("fname");
                    String col3 = ACV1.getString ("lname");
                    String col4 = ACV1.getString ("address");
                    String col5 = ACV1.getString ("email");
                    String col6 = ACV1.getString ("phone");
                    System.out.println("");
                    System.out.format("%20s %20s %20s %20s %20s %20s ", col1, col2, col3, col4, col5, col6);}
                
                //We print out the information from the price table
                Statement AC1 = con.createStatement ();
                ResultSet AC1V1 = AC1.executeQuery ("SELECT * FROM Price");
                System.out.println("\n");
                System.out.format("%20s %20s","Flight Number", "Price \n");
                System.out.print("-----------------------------------------");
                while (AC1V1.next ()){
                    String col1 = AC1V1.getString ("flightno");
                    String col2 = AC1V1.getString ("price");
                    System.out.println("");
                    System.out.format("%20s %20s", col1, col2);}
                    System.out.println("");
                
                break;
                
            case 3:
                //Optionm 3
                //Book Flight
                
                //Prints the flight table to the screen
                Statement BK = con.createStatement ();
                ResultSet BKV1 = BK.executeQuery ("SELECT * FROM Flights");
                System.out.println("");
                System.out.format("%20s %20s %20s %20s %20s", "Flight Number", "Source","Destination","E.T.A.","Number of passangers \n");
                System.out.print("----------------------------------------------------------------------------------------------------------");
                while (BKV1.next ()) {
                    String col1 = BKV1.getString ("flightno");
                    String col2 = BKV1.getString ("source");
                    String col3 = BKV1.getString ("destination");
                    String col4 = BKV1.getString ("eta");
                    String col5 = BKV1.getString ("numberpassenger");
                    System.out.println("");
                    System.out.format("%20s %20s %20s %20s %20s ", col1, col2, col3, col4, col5);}
                
                //Prints the price table to the screen
                Statement BK1 = con.createStatement ();
                ResultSet BK1V1 = BK1.executeQuery ("SELECT * FROM Price");
                System.out.println("\n");
                System.out.format("%20s %20s","Flight Number", "Price \n");
                System.out.print("-----------------------------------------");
                while (BK1V1.next ()){
                    String col1 = BK1V1.getString ("flightno");
                    String col2 = BK1V1.getString ("price");
                    System.out.println("");
                    System.out.format("%20s %20s", col1, col2);}
                    System.out.println("");
                   
                //Enters the information needed to book a flight
                String customersid, flightsno, payment;
                System.out.println("\nPlease Enter your customer id: ");
                customersid = input.next();
                System.out.println("\nPlease Enter the flight number you want to book: ");
                flightsno = input.next();
                System.out.println("\nWill you be paying now (yes/no): ");
                payment = input.next();
                
                //Inserts this information to the attendance table
                String insertSQLv10 = "Insert into attendance values (?, ?)";
                PreparedStatement insertStmtv11 = con.prepareStatement(insertSQLv10);
                insertStmtv11.setString(1, customersid);
                insertStmtv11.setString(2, flightsno);
                insertStmtv11.executeUpdate();
                insertStmtv11.close();
                
                //Inserts this information top the paid table
                String insertSQLv22 = "Insert into paid values (?, ?, ?)";
                PreparedStatement insertStmtev23 = con.prepareStatement(insertSQLv22);
                insertStmtev23.setString(1, customersid);
                insertStmtev23.setString(2, flightsno);
                insertStmtev23.setString(3, payment);
                insertStmtev23.executeUpdate();
                insertStmtev23.close();
                
                //Informs the screen it was sucessfull
                System.out.println("Request Processing");
                System.out.println("Flight booked");
                break;

            case 4: 
                //Optionm 4
                //List Airlines
                
                //List the Airlines to the screen
                Statement A = con.createStatement ();
                ResultSet AV1 = A.executeQuery ("SELECT * FROM Airlines");
                System.out.println("");
                System.out.format("%10s %20s", "Airlinename", "Airlineid \n");
                System.out.println("------------------------------------------");
                while (AV1.next ()){
                    String col1 = AV1.getString ("airlinename");
                    String col2 = AV1.getString ("airlineid");
                    System.out.format("%10s %20s", col1, col2);
                    System.out.println();
                }
                break;

            case 5:
                //Optionm 5
                //Make Payment
                
                //Prints the payment table to thge screen
                Statement P = con.createStatement ();
                ResultSet P1 = P.executeQuery ("SELECT * FROM Paid");
                System.out.println("");
                System.out.format("%20s %20s %20s", "CustomerID", "Flight Number","Paid or not \n");
                System.out.println("-------------------------------------------------------------");
                while (P1.next ()){
                    String col1 = P1.getString ("customerid");
                    String col2 = P1.getString ("flightno");
                    String col3 = P1.getString ("paidornot");
                    System.out.format("%20s %20s %20s", col1, col2, col3);
                    System.out.println();
                
                }
                P1.close();
                
                //Asks the questions needed to make a payment
                String cusid, cardid, pinid;
                System.out.println("\nPlease Enter your customer id: ");
                cusid = input.next();
                System.out.println("\nPlease Enter your card number: ");
                cardid = input.next();
                System.out.println("\nPlease Enter your pin number: ");
                pinid = input.next();
                
                //Updates the paid table
                String update = "Update paid SET paidornot = 'yes' WHERE customerid = ?; ";
                PreparedStatement P1V1 = con.prepareStatement(update);
                P1V1.setString(1, cusid);
                P1V1.executeUpdate();
                System.out.println("Payment Processing");
                System.out.println("Payment Received....Enjoy your Flight");
                P1V1.close();
                break;

            case 6:
                //Optionm 6
                //Flight Info
                
                //Prints the Flights table to the screen
                Statement F = con.createStatement ();
                ResultSet FV1 = F.executeQuery ("SELECT * FROM Flights");
                System.out.println("");
                System.out.format("%20s %20s %20s %20s %20s", "Flight Number", "Source","Destination","E.T.A.","Number of passangers \n");
                System.out.print("----------------------------------------------------------------------------------------------------------");
                while (FV1.next ()) {
                    String col1 = FV1.getString ("flightno");
                    String col2 = FV1.getString ("source");
                    String col3 = FV1.getString ("destination");
                    String col4 = FV1.getString ("eta");
                    String col5 = FV1.getString ("numberpassenger");
                    System.out.println("");
                    System.out.format("%20s %20s %20s %20s %20s ", col1, col2, col3, col4, col5);}
                   
                //Prints the Price table to the screen
                Statement F1 = con.createStatement ();
                ResultSet F1V1 = F1.executeQuery ("SELECT * FROM Price");
                System.out.println("\n");
                System.out.format("%20s %20s","Flight Number", "Price \n");
                System.out.print("-----------------------------------------");
                while (F1V1.next ()){
                    String col1 = F1V1.getString ("flightno");
                    String col2 = F1V1.getString ("price");
                    System.out.println("");
                    System.out.format("%20s %20s", col1, col2);}
                    System.out.println("");
                    break;

            case 7:
                //Optionm 7
                //Delete Airline
                
                //Prints the Airline table to the screen
                Statement AA1 = con.createStatement ();
                ResultSet AA1V1 = AA1.executeQuery ("SELECT * FROM Airlines");
                System.out.println("\n");
                System.out.format("%20s %20s","Airline Nmae", "Airline ID \n");
                System.out.print("-----------------------------------------");
                while (AA1V1.next ()){
                    String col1 = AA1V1.getString ("airlinename");
                    String col2 = AA1V1.getString ("airlineid");
                    System.out.println("");
                    System.out.format("%20s %20s", col1, col2);}
                    System.out.println("");
                
                //Asks the airline they want to delte
                String name;
                System.out.println("\nPlease choose the airline you wish to remove: ");
                name = input.next();
                
                //Deletes the desired Airline
                String deleteSQL = "Delete from  Airlines where airlinename =?";
                PreparedStatement deleteStmtev = con.prepareStatement(deleteSQL);
                deleteStmtev .setString(1, name);
                deleteStmtev .executeUpdate();
                deleteStmtev .close();
                
                break;
                 
            case 8: 
                // Option 8
                // This is to exit out of the menu
                System.out.println("\n Exiting Program...");
                System.exit(0);
                break;
                
            default :
                //Options outside of 1-8
                //It sends a message out if a invalid option is chosen
                //Then it breaks
                System.out.println("This is not a valid Menu Option! Please Select Another");
                break;

            }
            }
        }
        catch (Exception ex) {
            System.out.println("SQLException: " + ex.getMessage());
        };
    
    }
    
}
